package com.example.calculadoraimc

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val editPeso = findViewById<EditText>(R.id.editPeso)
        val editAltura = findViewById<EditText>(R.id.editAltura)
        val btnCalcular = findViewById<Button>(R.id.btnCalcular)

        btnCalcular.setOnClickListener {
            val peso = editPeso.text.toString().replace(',', '.').toDoubleOrNull()
            val altura = editAltura.text.toString().replace(',', '.').toDoubleOrNull()

            if (peso == null || altura == null || peso <= 0.0 || altura <= 0.0) {
                Toast.makeText(this, "Digite peso e altura válidos.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val imc = peso / (altura * altura)
            val intent = Intent(this, ResultadoActivity::class.java)
            intent.putExtra("IMC", imc)
            startActivity(intent)
        }
    }
}
