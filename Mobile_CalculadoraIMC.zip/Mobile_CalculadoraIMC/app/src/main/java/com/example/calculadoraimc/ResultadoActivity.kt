package com.example.calculadoraimc

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.util.Locale

class ResultadoActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resultado)

        val txtValorImc = findViewById<TextView>(R.id.txtValorImc)
        val txtClassificacao = findViewById<TextView>(R.id.txtClassificacao)
        val btnVoltar = findViewById<Button>(R.id.btnVoltar)

        val imc = intent.getDoubleExtra("IMC", 0.0)
        val classificacao = when {
            imc < 18.5 -> "Abaixo do peso"
            imc < 25.0 -> "Peso normal"
            imc < 30.0 -> "Sobrepeso"
            imc < 35.0 -> "Obesidade grau I"
            imc < 40.0 -> "Obesidade grau II"
            else -> "Obesidade grau III"
        }

        txtValorImc.text = String.format(Locale.US, "IMC: %.2f", imc)
        txtClassificacao.text = "Classificação: $classificacao"
        btnVoltar.setOnClickListener { finish() }
    }
}
